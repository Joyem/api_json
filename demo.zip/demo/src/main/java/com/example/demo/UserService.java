package com.example.demo;

import org.springframework.stereotype.Component;

import java.util.List;
public interface UserService {
    public boolean addUser(User user);
    public boolean deleteUser(int id);
    public boolean updateUser(User user);
    public User findById(int userid);
    public List<User> findByname(String username);

}
