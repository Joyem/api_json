package com.example.demo;

import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.List;
@Mapper
public  interface UserDao {
    //用户新增
    @Insert("insert into user(id,name,sex,age) values(#{id},#{name},#{sex},#{age})")
    public void addUser(User user);
    //更新用户
    @Update("update user set name=#{user.name},age=#{user.age},sex=#{user.sex} where id=#{user.id}")
    public void updateUser(User user);
    //删除用户
    @Delete("delete from user where id=#{id}")
    public void deleteUser(int id);
    //根据用户id查询用户信息
    @Select("select id,name,sex,age from user where id=#{userid}")
    public User findById(@Param("userid") int userId);

    //根据用户名称查询用户信息
    @Select("select id,name,sex,age from user where name=#{username}")
    public List<User> findByname(@Param("username") String username);

}
