package com.example.demo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/demo")
public class UserRequest {
    @Autowired
    UserService userService;
    @RequestMapping(value = "/adduser")
    public boolean addUser(User user){
        return userService.addUser(user);
    }
    @RequestMapping(value = "/deleteuser",method = RequestMethod.DELETE)
    public boolean deleteUser(int id){
        return userService.deleteUser(id);
    }
    @RequestMapping(value = "/updateuser",method = RequestMethod.PUT)
    public boolean updateuser(User user){
        return userService.updateUser(user);
    }
    @RequestMapping(value = "/findbyid",method = RequestMethod.GET)
    public User findbyid(int id){
        return userService.findById(id);
    }
    @RequestMapping(value = "/findbyname",method = RequestMethod.GET)
    public List<User> findbyname(String name){
        return userService.findByname(name);
    }
}
