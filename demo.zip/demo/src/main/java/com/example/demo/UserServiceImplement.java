package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class UserServiceImplement implements UserService {
    @Autowired
    private UserDao userDao;
    @Override
    public boolean addUser(User user) {
        boolean flag = false;
        try {
            userDao.addUser(user);
            flag = true;
        }catch (Exception e){
            e.printStackTrace();
        }
        System.out.println("用户添加成功!"+user.getName());
        return flag;
    }

    @Override
    public boolean deleteUser(int id) {
        boolean flag = false;
        try{
            userDao.deleteUser(id);
            flag = true;
        }catch (Exception e){
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public boolean updateUser(User user) {
        boolean flag = false;
        try{
            userDao.updateUser(user);
            flag = true;
        }catch (Exception e){
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public User findById(int userid) {
        User user = null;
        try{
            user = userDao.findById(userid);
        }catch (Exception e){
            e.printStackTrace();
        }
        return user;
    }

    @Override
    public List<User> findByname(String username) {
        List<User> list = null;
        try{
            list = userDao.findByname(username);
        }catch (Exception e){
            e.printStackTrace();
        }
        return list;
    }
}
