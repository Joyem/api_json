package com.example.mybatis_demo;

import java.util.Random;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class multithread {
    static ThreadPoolExecutor executor = new ThreadPoolExecutor(2,5,2000, TimeUnit.MILLISECONDS,new LinkedBlockingDeque<>(5),new ThreadPoolExecutor.DiscardPolicy());
    private static int cpu = Runtime.getRuntime().availableProcessors();//cpu核数
    private static double filesize = Math.ceil(new Random().nextDouble()*1000);
    private static int singlesize = (int)Math.ceil(filesize / cpu);
    public static void main(String args[]){
        System.out.println("文件大小:"+filesize);
        for(int i=0;i<cpu;i++){

            int start = i * singlesize;
            int end = (i+1) * singlesize -1;
            executor.submit(new mythread(i,start,end));

        }
    }

}
