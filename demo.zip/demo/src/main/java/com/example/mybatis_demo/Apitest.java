package com.example.mybatis_demo;

import com.alibaba.fastjson.JSONObject;
import com.example.apidemo.User;
import com.example.apidemo.getJson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


public class Apitest {
    /*
    @Autowired
    JdbcTemplate jdbcTemplate;
    @Autowired
    com.example.apidemo.getJson getJson;
    @RequestMapping("/getsessionkey")
    public void getSessionkey(){
        JSONObject jsonObject = getJson.getJson("getSessionKey&password=123456&username=cmadr");
        System.out.println(jsonObject.toJSONString());
    }

    @RequestMapping("/loginbusiness")
    public User main1(){
        //getJson getJson
        JSONObject jsonObject = getJson.getJson("method=loginBusiness&businessUsername=cmadr&businessPassword=123456");

        User user= new User(jsonObject.getString("orginfo"),jsonObject.getString("comobj"),jsonObject.getInteger("ring"),
                jsonObject.getString("sessionkey"),jsonObject.getString("ysAppkey"),jsonObject.getString("ysSecket"),
                jsonObject.getString("ysUsername"),jsonObject.getString("ysPassword"),jsonObject.getInteger("loginid"),
                jsonObject.getInteger("operatorid"),jsonObject.getInteger("custid"));
        String sql = "insert into user(orginfo, comobj, ring, sessionkey, ysAppkey, ysSecket, ysUsername, ysPassword, loginid, operatorid, custid)values(?,?,?,?,?,?,?,?,?,?,?)";
        jdbcTemplate.update(sql,user.getOrginfo().toString(),user.getComobj().toString(),user.getRing(),user.getSessionkey(),user.getYsAppkey(),user.getYsSecket(),user.getYsUsername(),user.getYsPassword(),user.getLoginid(),user.getOperatorid(),user.getCustid());

        System.out.println("数据库插入user成功");
        return user;
    }
    @RequestMapping("detaildata")
    public void  getRealTimeDeviceDetailData(){
        JSONObject jsonObject = getJson.getJson("username=cmadr&method=getRealTimeDeviceDetailData&addr=44041330");
        System.out.println(jsonObject.toJSONString());
    }



*/
}