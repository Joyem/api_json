package com.example.mybatis_demo;

public class mythread implements Runnable {
    private int id;
    private int start;
    private int end;
    @Override
    public void run() {

        System.out.println("线程："+id+"下载范围:"+start+"-"+end);
        System.out.println("线程"+id+"运行完成");
    }
    public mythread(){}
    public mythread(int id,int start,int end){
        this.id = id;
        this.end = end;
        this.start = start;

    }

}
