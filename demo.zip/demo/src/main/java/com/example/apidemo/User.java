package com.example.apidemo;

public class User {
    private String orginfo;
    private String comobj;
    private int ring;
    private String sessionkey;
    private String ysAppkey;
    private String ysSecket;
    private String ysUsername;
    private String ysPassword;
    private int loginid;
    private int operatorid;
    private int custid;

    public User(){}

    @Override
    public String toString() {
        return "user[orginfo:"+orginfo+"comobj:"+comobj+"ring:"+ring+"]";
    }

    public User(String orginfo, String comobj, int ring, String sessionkey, String ysAppkey, String ysSecket
            , String ysUsername, String ysPassword, int loginid, int operatorid, int custid){
        this.comobj = comobj;
        this.orginfo = orginfo;
        this.ring = ring;
        this.sessionkey = sessionkey;
        this.ysAppkey = ysAppkey;
        this.ysSecket = ysSecket;
        this.ysUsername = ysUsername;
        this.ysPassword = ysPassword;
        this.loginid = loginid;
        this.operatorid = operatorid;
        this.custid = custid;
    }

    public int getCustid() {
        return custid;
    }

    public int getLoginid() {
        return loginid;
    }



    public int getRing() {
        return ring;
    }

    public int getOperatorid() {
        return operatorid;
    }

    public String getComobj() {
        return comobj;
    }

    public String getSessionkey() {
        return sessionkey;
    }

    public String getYsAppkey() {
        return ysAppkey;
    }

    public String getYsPassword() {
        return ysPassword;
    }

    public String getYsSecket() {
        return ysSecket;
    }

    public String getYsUsername() {
        return ysUsername;
    }

    public void setComobj(String comobj) {
        this.comobj = comobj;
    }

    public void setLoginid(int loginid) {
        this.loginid = loginid;
    }

    public void setOperatorid(int operatorid) {
        this.operatorid = operatorid;
    }

    public void setOrginfo(String orginfo) {
        this.orginfo = orginfo;
    }

    public void setRing(int ring) {
        this.ring = ring;
    }

    public void setSessionkey(String sessionkey) {
        this.sessionkey = sessionkey;
    }

    public void setYsAppkey(String ysAppkey) {
        this.ysAppkey = ysAppkey;
    }

    public void setYsPassword(String ysPassword) {
        this.ysPassword = ysPassword;
    }

    public void setYsUsername(String ysUsername) {
        this.ysUsername = ysUsername;
    }


    public void setYsSecket(String ysSecket) {
        this.ysSecket = ysSecket;
    }

    public void setCustid(int custid) {
        this.custid = custid;
    }

    public String getOrginfo() {
        return orginfo;
    }
}
