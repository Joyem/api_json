package com.example.apidemo;


public class ComobjEntity {
    private String address;
    private String adminName;
    private String areaId;
    private String companyName;
    private Integer companyType;
    private String contact;
    private String email;
    private Double farmArea;
    private String geom;
    private Integer id;
    private Integer internalId;
    private String internalName;
    private String mobile;
    private String postcode;
    private String projectInfo;
    private String province;
    private String remark;
    private Integer state;
    private String telephone;

    public ComobjEntity(){}
    public ComobjEntity(String address, String adminName, String areaId, String companyName, Integer companyType, String contact, String email, Double farmArea, String geom, Integer id, Integer internalId, String internalName, String mobile, String postcode, String projectInfo, String province, String remark, Integer state, String telephone, String ysAppkey, String ysPassword, String ysSecket, String ysToken, String ysUsername) {
        this.address = address;
        this.adminName = adminName;
        this.areaId = areaId;
        this.companyName = companyName;
        this.companyType = companyType;
        this.contact = contact;
        this.email = email;
        this.farmArea = farmArea;
        this.geom = geom;
        this.id = id;
        this.internalId = internalId;
        this.internalName = internalName;
        this.mobile = mobile;
        this.postcode = postcode;
        this.projectInfo = projectInfo;
        this.province = province;
        this.remark = remark;
        this.state = state;
        this.telephone = telephone;
        this.ysAppkey = ysAppkey;
        this.ysPassword = ysPassword;
        this.ysSecket = ysSecket;
        this.ysToken = ysToken;
        this.ysUsername = ysUsername;
    }

    private String ysAppkey;
    private String ysPassword;
    private String ysSecket;
    private String ysToken;
    private String ysUsername;


    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }


    public String getAdminName() {
        return adminName;
    }

    public void setAdminName(String adminName) {
        this.adminName = adminName;
    }


    public String getAreaId() {
        return areaId;
    }

    public void setAreaId(String areaId) {
        this.areaId = areaId;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }


    public Integer getCompanyType() {
        return companyType;
    }

    public void setCompanyType(Integer companyType) {
        this.companyType = companyType;
    }


    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }


    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }


    public Double getFarmArea() {
        return farmArea;
    }

    public void setFarmArea(Double farmArea) {
        this.farmArea = farmArea;
    }


    public String getGeom() {
        return geom;
    }

    public void setGeom(String geom) {
        this.geom = geom;
    }


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }


    public Integer getInternalId() {
        return internalId;
    }

    public void setInternalId(Integer internalId) {
        this.internalId = internalId;
    }


    public String getInternalName() {
        return internalName;
    }

    public void setInternalName(String internalName) {
        this.internalName = internalName;
    }


    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getPostcode() {
        return postcode;
    }

    public void setPostcode(String postcode) {
        this.postcode = postcode;
    }

    public String getProjectInfo() {
        return projectInfo;
    }

    public void setProjectInfo(String projectInfo) {
        this.projectInfo = projectInfo;
    }


    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }


    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }


    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }


    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }


    public String getYsAppkey() {
        return ysAppkey;
    }

    public void setYsAppkey(String ysAppkey) {
        this.ysAppkey = ysAppkey;
    }


    public String getYsPassword() {
        return ysPassword;
    }

    public void setYsPassword(String ysPassword) {
        this.ysPassword = ysPassword;
    }


    public String getYsSecket() {
        return ysSecket;
    }

    public void setYsSecket(String ysSecket) {
        this.ysSecket = ysSecket;
    }


    public String getYsToken() {
        return ysToken;
    }

    public void setYsToken(String ysToken) {
        this.ysToken = ysToken;
    }


    public String getYsUsername() {
        return ysUsername;
    }

    public void setYsUsername(String ysUsername) {
        this.ysUsername = ysUsername;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ComobjEntity that = (ComobjEntity) o;

        if (address != null ? !address.equals(that.address) : that.address != null) return false;
        if (adminName != null ? !adminName.equals(that.adminName) : that.adminName != null) return false;
        if (areaId != null ? !areaId.equals(that.areaId) : that.areaId != null) return false;
        if (companyName != null ? !companyName.equals(that.companyName) : that.companyName != null) return false;
        if (companyType != null ? !companyType.equals(that.companyType) : that.companyType != null) return false;
        if (contact != null ? !contact.equals(that.contact) : that.contact != null) return false;
        if (email != null ? !email.equals(that.email) : that.email != null) return false;
        if (farmArea != null ? !farmArea.equals(that.farmArea) : that.farmArea != null) return false;
        if (geom != null ? !geom.equals(that.geom) : that.geom != null) return false;
        if (id != null ? !id.equals(that.id) : that.id != null) return false;
        if (internalId != null ? !internalId.equals(that.internalId) : that.internalId != null) return false;
        if (internalName != null ? !internalName.equals(that.internalName) : that.internalName != null) return false;
        if (mobile != null ? !mobile.equals(that.mobile) : that.mobile != null) return false;
        if (postcode != null ? !postcode.equals(that.postcode) : that.postcode != null) return false;
        if (projectInfo != null ? !projectInfo.equals(that.projectInfo) : that.projectInfo != null) return false;
        if (province != null ? !province.equals(that.province) : that.province != null) return false;
        if (remark != null ? !remark.equals(that.remark) : that.remark != null) return false;
        if (state != null ? !state.equals(that.state) : that.state != null) return false;
        if (telephone != null ? !telephone.equals(that.telephone) : that.telephone != null) return false;
        if (ysAppkey != null ? !ysAppkey.equals(that.ysAppkey) : that.ysAppkey != null) return false;
        if (ysPassword != null ? !ysPassword.equals(that.ysPassword) : that.ysPassword != null) return false;
        if (ysSecket != null ? !ysSecket.equals(that.ysSecket) : that.ysSecket != null) return false;
        if (ysToken != null ? !ysToken.equals(that.ysToken) : that.ysToken != null) return false;
        if (ysUsername != null ? !ysUsername.equals(that.ysUsername) : that.ysUsername != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = address != null ? address.hashCode() : 0;
        result = 31 * result + (adminName != null ? adminName.hashCode() : 0);
        result = 31 * result + (areaId != null ? areaId.hashCode() : 0);
        result = 31 * result + (companyName != null ? companyName.hashCode() : 0);
        result = 31 * result + (companyType != null ? companyType.hashCode() : 0);
        result = 31 * result + (contact != null ? contact.hashCode() : 0);
        result = 31 * result + (email != null ? email.hashCode() : 0);
        result = 31 * result + (farmArea != null ? farmArea.hashCode() : 0);
        result = 31 * result + (geom != null ? geom.hashCode() : 0);
        result = 31 * result + (id != null ? id.hashCode() : 0);
        result = 31 * result + (internalId != null ? internalId.hashCode() : 0);
        result = 31 * result + (internalName != null ? internalName.hashCode() : 0);
        result = 31 * result + (mobile != null ? mobile.hashCode() : 0);
        result = 31 * result + (postcode != null ? postcode.hashCode() : 0);
        result = 31 * result + (projectInfo != null ? projectInfo.hashCode() : 0);
        result = 31 * result + (province != null ? province.hashCode() : 0);
        result = 31 * result + (remark != null ? remark.hashCode() : 0);
        result = 31 * result + (state != null ? state.hashCode() : 0);
        result = 31 * result + (telephone != null ? telephone.hashCode() : 0);
        result = 31 * result + (ysAppkey != null ? ysAppkey.hashCode() : 0);
        result = 31 * result + (ysPassword != null ? ysPassword.hashCode() : 0);
        result = 31 * result + (ysSecket != null ? ysSecket.hashCode() : 0);
        result = 31 * result + (ysToken != null ? ysToken.hashCode() : 0);
        result = 31 * result + (ysUsername != null ? ysUsername.hashCode() : 0);
        return result;
    }
}
