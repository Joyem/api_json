package com.example.apidemo;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jackson.JsonObjectDeserializer;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class Mainthread {
    @Autowired
    getJson getJson;
    @Autowired
    JdbcTemplate jdbcTemplate;

    @RequestMapping("/comobj")
    public String getcomobj(){
        JSONObject jsonObject = getJson.getJson("method=loginBusiness&businessUsername=cmadr&businessPassword=123456");
        System.out.println("json获取成功!");
        String comobj = jsonObject.getString("comobj");
        System.out.println("comobj获取成功"+comobj);
        JSONObject comobjson = JSON.parseObject(comobj);
        //ComobjEntity(String address, String adminName, String areaId, String companyName, Integer companyType, String contact, String email, Double farmArea, String geom, Integer id, Integer internalId, String internalName, String mobile, String postcode, String projectInfo, String province, String remark, address, String adminName, String areaId, String companyName, Integer companyType, String contact, String email, Double farmArea, String geom, Integer id, Integer internalId, String internalName, String mobile, String postcode, String projectInfo, String province, String remark, Integer state, String telephone, String ysAppkey, String ysPassword, String ysSecket, String ysToken, String ysUsername state, String telephone, String ysAppkey, String ysPassword, String ysSecket, String ysToken, String ysUsername)

        System.out.println("combojson.companyName="+comobjson.getString("companyName"));
        ComobjEntity comobjEntity = new ComobjEntity(comobjson.getString("address"),comobjson.getString("adminName"),comobjson.getString("areaId"),comobjson.getString("companyName"),comobjson.getInteger("companyType"),comobjson.getString("contact"),comobjson.getString("email"),comobjson.getDouble("farmArea"),comobjson.getString("geom"),comobjson.getInteger("id"),comobjson.getInteger("internalId"),comobjson.getString("internalName"),comobjson.getString("mobile"),comobjson.getString("postcode"),comobjson.getString("projectInfo"),comobjson.getString("province"),comobjson.getString("remark"),comobjson.getInteger("state"),comobjson.getString("telephone"),comobjson.getString("ysAppkey"),comobjson.getString("ysPassword"),comobjson.getString("ysSecket"),comobjson.getString("ysToken"),comobjson.getString("ysUsername"));
        String sql = "insert into comobj(address,  adminName,  areaId,  companyName,  companyType,  contact,  email,  farmArea,  geom,  id,  internalId,  internalName,  mobile,  postcode,  projectInfo,  province,  remark,  state,  telephone,  ysAppkey,  ysPassword,  ysSecket,  ysToken,  ysUsername)values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        jdbcTemplate.update(sql,comobjson.getString("address"),comobjson.getString("adminName"),comobjson.getString("areaId"),comobjson.getString("companyName"),comobjson.getInteger("companyType"),comobjson.getString("contact"),comobjson.getString("email"),comobjson.getDouble("farmArea"),comobjson.getString("geom"),comobjson.getInteger("id"),comobjson.getInteger("internalId"),comobjson.getString("internalName"),comobjson.getString("mobile"),comobjson.getString("postcode"),comobjson.getString("projectInfo"),comobjson.getString("province"),comobjson.getString("remark"),comobjson.getInteger("state"),comobjson.getString("telephone"),comobjson.getString("ysAppkey"),comobjson.getString("ysPassword"),comobjson.getString("ysSecket"),comobjson.getString("ysToken"),comobjson.getString("ysUsername"));

        return "前台用户登陆接口更新成功！";
    }
}
