package com.example.mybatis;

import com.example.mybatis.User;
import com.example.mybatis.UserService;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {
    @Autowired
    private UserService userService;
    @RequestMapping("/findAll")
    public List<User> findAll(){
        userService.insert("name2","男");
        List<User> userList = userService.findAll();
        for(User user:userList){
            System.out.println("用户:"+user.getName());
        }
        return userList;
    }

    @RequestMapping("/findById")
    public User findById( int i){
        User user = userService.findById(i);
        System.out.println("用户Id==1:"+user.getName());
        return user;
    }
    @RequestMapping("/insert")
    public String insert(@RequestParam("name") String name, @RequestParam("sex") String sex)
    {
        System.out.println("新增用户");
        int result = userService.insert(name,sex);
        if(result==1) {
            System.out.println("新增成功");
            return "success";
    }else {
        System.out.println("新增失败");
        return "error";
        }
    }

}
