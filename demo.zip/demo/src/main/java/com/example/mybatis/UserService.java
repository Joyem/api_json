package com.example.mybatis;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
@Component
public class UserService {
    @Autowired
    private UserMapper userMapper;
    public List<User> findAll(){
        System.out.println("findAll运行成功");
        //userMapper.insert("name111","男");
        return userMapper.findAll();
    }
    public User findById(int id){
        System.out.println("findById运行成功");
        return userMapper.findById(id);
    }
    public int insert(String name,String sex){
        System.out.println("insert运行成功");
        return userMapper.insert(name,sex);
    }
    public int update(User user){
        System.out.println("update运行成功");
        return userMapper.update(user);
    }
    public int delete(int id){
        System.out.println("delete运行成功");
        return userMapper.delete(id);
    }

}
