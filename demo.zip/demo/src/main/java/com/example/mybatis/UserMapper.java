package com.example.mybatis;

import com.example.mybatis.User;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface UserMapper {
    @Select("select * from user")
    List<com.example.mybatis.User> findAll();
    @Select("select * from user where id=#{id}")
    com.example.mybatis.User findById(@Param("id") int id);
    @Insert("insert into user(name,sex) values(#{name},#{sex})")
    int insert(@Param("name")String name,@Param("sex") String sex);
    @Update("update user set name = #{name} where id = #{id}")
    int update(User user);
    @Delete("delete from user where id=#{id}")
    int delete(int id);
}
